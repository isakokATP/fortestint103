import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static JournalManager journalManager = new JournalManager();

    public static void main(String[] args) {
        testWriterEntry();
        readFile();
    }


    private static void testWriterEntry(){
        System.out.println("write your Entry: ");
        String text = scanner.nextLine();
        JournalEntry journalEntry = new JournalEntry(LocalDateTime.now(),text);
//        JournalManager journalManager = new JournalManager();
        try {
            journalManager.writeEntry(journalEntry);
        } catch (Exception e) {
            System.out.println("Error writing entry :" + e.getMessage());
        }
    }
    private static void readFile(){
        try {
            List<JournalEntry> entries = journalManager.readEntries();
            if (entries.isEmpty()){
                System.out.println("No entries found");
            } else {
                System.out.println("All Entries");
                for (JournalEntry entry: entries){
                    System.out.println(entry);
                }
            }
        } catch (IOException e) {
            System.out.println("Error to read file" + e.getMessage());
        }
    }
}