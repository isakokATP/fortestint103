import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class JournalManager {
    private static final String journal = "journal.txt";
    public static final DateTimeFormatter DateTimeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public void writeEntry(JournalEntry entry) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(journal, true))) {
            bw.write(entry.toString());
            bw.newLine();
        }
    }

    public List<JournalEntry> readEntries() throws IOException {
        List<JournalEntry> entries = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(journal))) {
            String line;
            while ((line = br.readLine()) != null) {
                LocalDateTime time = LocalDateTime.parse(line.substring(0, 19), DateTimeFormat);
//                System.out.println(time);
                String text = line.substring(22);
                entries.add(new JournalEntry(time, text));
            }
        }
        return entries;
    }

}
