import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class JournalEntry {
    private LocalDateTime timeStamp;
    private String text;

    public JournalEntry( LocalDateTime timeStamp,String text) {
        this.timeStamp = timeStamp;
        this.text = text;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public String getText() {
        return text;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return timeStamp.format(formatter) + " - " + text;
    }
}
